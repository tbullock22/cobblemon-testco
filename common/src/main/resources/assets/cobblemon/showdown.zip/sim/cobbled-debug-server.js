"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cobbled_debug_server_exports = {};
__export(cobbled_debug_server_exports, {
  startServer: () => startServer
});
module.exports = __toCommonJS(cobbled_debug_server_exports);
var import_battle_stream = require("./battle-stream");
var Net = __toESM(require("net"));
function startServer(port) {
  const server = Net.createServer();
  server.listen(port, () => {
    console.log("Server listening for connection requests on socket localhost: " + port);
  });
  server.on("connection", (socket) => {
    const battle = new import_battle_stream.BattleStream();
    console.log("A new connection has been established.");
    socket.write("ready");
    socket.on("data", (chunk) => {
      console.log("Data received from client: " + chunk.toString());
      try {
        void battle.write(chunk.toString());
      } catch (error) {
        console.error(error.toString());
        console.error(error.stack);
        socket.write(error.toString());
      }
    });
    socket.on("end", function() {
      console.log("Closing connection with the client");
    });
    socket.on("error", function(err) {
      console.log(`Error: ${err}`);
    });
    void (async () => {
      for await (const output of battle) {
        socket.write(output);
      }
    })();
  });
}
//# sourceMappingURL=cobbled-debug-server.js.map
